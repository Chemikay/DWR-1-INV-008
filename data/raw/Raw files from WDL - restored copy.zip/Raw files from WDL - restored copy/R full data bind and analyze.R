library(writexl)
library(tidyverse)
library(data.table)
library(readxl)
library(janitor)

#Pull in all original WDL data sets into one dataframe
filelist = list.files(path = "~/Projects/Field Lab SC/Raw files from WDL/",    
                      pattern = "*.xlsx",
                      full.names = F) 
gfg_data =  list.files(path = "~/Projects/Field Lab SC/Raw files from WDL/",    
                       pattern = "*.xlsx",
                       full.names = T) %>%
  lapply(read_excel) 

attr(gfg_data, "names") <- filelist

gfg_data2 = rbindlist(gfg_data,idcol="id", fill =T)

gfg_data2 <- clean_names(gfg_data2)

View(gfg_data2)

names(gfg_data2)

#now read in the data from Kelley (data from her internal WDL for time period not captured, some overlap)

kelley = read_excel("~/Projects/Field Lab SC/SC Field and Lab_Dec2022-Feb2023_SomeProjects.xlsx")

kelley <- clean_names(kelley)

names(kelley)

#need to recreate the 'unique_field' and 'unique_lab' data for this new dataset,

kelley = mutate(kelley, id = paste(data_owner_id, data_owner))

names(gfg_data2)
names(kelley)
unique(kelley$lab_method_name)
unique(kelley$lab_method_title)
str(kelley)

#plus standardize the names
kelley = mutate(kelley, lab_result = as.numeric(lab_result),
               field_analyte_name = paste(field_fraction_name, field_measure_name),
               collection_date2 = as.character(format(collection_date, format = "%m/%d/%Y %H:%M")),
               unique_field = paste(collection_date2, field_result),
               unique_lab = paste(collection_date2, lab_result))
unique(kelley$field_analyte_name)


unique(gfg_data2$analyte)

#not using this next lines 57-59 for now 8-21-23 #move results in gfg_data2 for field EC and SC into one field results column since electrical conductance has been confirmed to truly be specific conductance values by affected programs

#gfg_data2_long = pivot_longer(gfg_data2, cols = c(result_field_electrical_conductance, result_field_specific_conductance),
                             #names_to = "parameter",
                             #values_to = "results_field_SC")

names(gfg_data2)

unique(gfg_data2$analyte)     

gfg_data2 <- clean_names(gfg_data2)

#remove columns not needed to clean up
gfg_data2 = select (gfg_data2,data_owner, long_station_name, sample_code,collection_date, analyte,result,
                    rpt_limit,units,method)

#filter out all other methods not related to conductivity
unique(gfg_data2$method)
gfg_data3 = filter(gfg_data2, method =="Std Method 2510-B [1]*"| method =="EPA 120.1 (Field) [1]*"| method =="Std Method 2510-B (Field) [1]*"|method =="Std Method 2510 B (Filtered)[1]*")

                    
#need to separate out field SC from lab SC, issue with duplicates so using id_cols, but doesn't feel right (all lab sc has value)
gfg_data3_wide <- gfg_data3 %>% 
  pivot_wider(id_cols = c(long_station_name, sample_code, collection_date),
              names_from = analyte, values_from = c(result, rpt_limit, method),
              values_fill = NA, values_fn = first)
#stopped here on 8/21

#group by field 

gfg_data3_long = pivot_longer(gfg_data3_wide, cols = c(field_specific_conductance, field_electrical_conductance, field_bottom_specific_conductance ),
                    names_to = "field_analyte_name",
                    values_to = "results_field_SC")

gfg_data2_long = select (gfg_data2_long,data_owner, long_station_name, sample_code,collection_date,results_field_SC,
                    rpt_limit,units,method, field_analyte_name,specific_conductance)


#need to create unique lab & field like for kelley dataset (need to finish, 10:45a)
gfg_data2 = mutate(gfg_data2, 
                unique_field = paste(collection_date2, field_result),
                unique_lab = paste(collection_date2, lab_result))


#need to separate out field and lab conductance in gfg_data2 (make gfg_data3)
#hint: new column that says field or lab, and function Rosie can send which looks for the names 'field' or 'lab', pivot based on field and lab

#remove unnecessary columns from kelley and gfg_data3
kelley1 <- select(kelley,#add column names to keep)  

gfg_data4 <-select(gfg_data3,#add column names to keep)

#rename columns in kelley1 for binding compatibility
#how to run single line of code and rename multiple columns?
kelley1 <- kelley1 %>% rename_at('current columns name', ~'new column name')

#rename columns in gfg_data4 for binding compatibility
gfg_data4 <- gfg_data4 %>% rename_at('current column name', ~'new columns name')

#bind kelley1 and gfg_data4
gfg_data5 = bind_rows(gfg_4, kelley1)

#perform RPD calculation in gfg_data5
gfg_data5_RPD <- gfg_data5 %>% 
  mutate(RPD =  100*((#field sc-#lab sc)/(#field sc + #lab sc))/2)

#identify lab duplicates
    
#remove lab duplicates
    
#identify duplicates from >1 project
    
#remove duplicates from >1 project